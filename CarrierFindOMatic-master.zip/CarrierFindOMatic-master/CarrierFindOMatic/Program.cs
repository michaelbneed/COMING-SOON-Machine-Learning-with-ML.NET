﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using System.Data.SqlClient;
using Microsoft.ML;
using Microsoft.ML.Data;
using Microsoft.ML.Trainers;
using System.IO;
using Microsoft.ML.Models;
using System.Diagnostics;
using Microsoft.ML.Runtime;
using Microsoft.ML.Runtime.EntryPoints;
using Zotec.ML.Extensions;
using CachingOptions = Microsoft.ML.Models.CachingOptions;

namespace CarrierFindOMatic
{
    class Program
    {

        private static string _connectionString;

        static void Main(string[] args)
        {


            Stopwatch stopWatch = new Stopwatch();
            var testingData = new List<CarrierInput>();
            var trainingData = new List<CarrierInput>();
            int totalCount;
            _connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Enterprise"].ConnectionString;


            var dataSources = new List<string>()
            {
                "SOUND"
                //,"MBS02"
                //,"RADPAR"
                //,"RADIA"
                //,"SIMONMED"
                //,"SWRADIOLOGY2"
            };

            //Training
            foreach (var currentClient in dataSources)
            {
                var modelType = GetModelType(currentClient);
                // if (ModelManagement<CarrierInput, ClassificationPrediction>.GetPredictionModelInformation(_connectionString, modelType) == null)
                if(1==1)
                {
                    Console.WriteLine($"Gettting training data for {currentClient} ...");
                    var sql = SQLLogic.carrierTrainingSql(currentClient);
                    testingData = GetTestData(_connectionString, sql);

                    Console.WriteLine($"Training {currentClient} ...");
                    stopWatch.Reset();
                    stopWatch.Start();

                    var algo = new StochasticDualCoordinateAscentClassifier()
                    {
                        Caching = CachingOptions.Memory,
                        MaxIterations = 100,
                        LossFunction = new SmoothedHingeLossSDCAClassificationLossFunction(),
                        NumThreads =
                            System.Environment.ProcessorCount - 1 //We use one less than the number of processors available,
                    };
                    var model = TrainModel(algo, testingData, currentClient);

                    ModelManagement<CarrierInput, ClassificationPrediction>.SaveModelToDb(model, modelType, _connectionString);
                    var trainingTime = stopWatch.Elapsed;
                    Console.WriteLine($"training Time for {currentClient}: {trainingTime}");
                }
            }

            //Testing
            foreach (var currentClient in dataSources)
            {
                Console.WriteLine($"Getting testing data for { currentClient } ...");
                var sql = SQLLogic.carrierTestingSql(currentClient);
                testingData = GetTestData(_connectionString, sql);
                totalCount = testingData.Count();
                Console.WriteLine($"Total data set for testing is: { totalCount }");

                stopWatch.Reset();
                stopWatch.Start();
                Console.WriteLine($"Starting predictions for { currentClient } ...");

                var modelType = GetModelType(currentClient);
                var predictedValues = MakePredictions(testingData, _connectionString, modelType);

                var predictionTime = stopWatch.Elapsed;
                Console.WriteLine($"Prediction Time(seconds): { predictionTime }");
                Console.WriteLine($"Items Predicted Per Second: { totalCount / (predictionTime.TotalSeconds) }");
                Console.WriteLine($"Percentage Match: { ((double)predictedValues.Count(p => p.Answer == p.PredictedValue) / (double)totalCount) * 100.00 }%");
                SaveResultsToCsv(predictedValues, currentClient);
                Console.WriteLine("Finished....");
            }

            Console.WriteLine("Totally finished now....press a key to exit");
            Console.ReadLine();
        }

 
        private static PredictionModel<CarrierInput, ClassificationPrediction> TrainModel(ILearningPipelineItem algorithm, List<CarrierInput> trainingData, string currentClient)
        {
            var modelType = GetModelType(currentClient);
            Console.WriteLine($"Total data set for training is: { trainingData.Count }");
            var trainingDataCollection = CollectionDataSource.Create(trainingData);
            var modelBuilder = new ModelBuilder<CarrierInput, ClassificationPrediction>(
                algorithm,
                nameof(CarrierInput.Features),
                modelType);
            modelBuilder.BuildAndTrain(trainingDataCollection, true);
            var testingDataCollection = CollectionDataSource.Create(trainingData);
            var stochasticDCAMetrics = modelBuilder.Evaluate(testingDataCollection);
            PrintClassificationMetrics("Stochastic Dual Coordinate Ascent Classifier", stochasticDCAMetrics);

            return modelBuilder.Model;
        }

        private static void PrintClassificationMetrics(string name, ClassificationMetrics metrics)
        {
            Console.WriteLine($"*************************************************");
            Console.WriteLine($"*       Metrics for {name}          ");
            Console.WriteLine($"*------------------------------------------------");
            Console.WriteLine($"*       Accuracy Macro: {metrics.AccuracyMacro}");
            Console.WriteLine($"*       Accuracy Micro: {metrics.AccuracyMicro}");
            Console.WriteLine($"*       Log Loss: {metrics.LogLoss}");
            Console.WriteLine($"*       Log Loss Reduction: {metrics.LogLossReduction}");
            Console.WriteLine($"*       Per Class Log Loss: {metrics.PerClassLogLoss}");
            Console.WriteLine($"*************************************************");
        }


        private static  List<CarrierAIInputExcel> MakePredictions(List<CarrierInput> testingData, string connectionString, string modelType)
        {
            var predictor = ModelManagement<CarrierInput, ClassificationPrediction>.LoadModelFromDBAsync(connectionString, modelType);

            var predictedValues = new List<CarrierAIInputExcel>();
            string[] labelNames;
            var total = testingData.Count;
            int counter = 1;
            predictor.TryGetScoreLabelNames(out labelNames);
            foreach (var item in testingData)
            {
                var prediction = predictor.Predict(item);
                var i = Array.IndexOf(labelNames, prediction.PredictedLabel);
                var predictedValue = new CarrierAIInputExcel()
                {
                    Answer = item.CarrierID,
                    PredictedValue = prediction.PredictedLabel,
                    Confidence = prediction.ConfidenceToNext(),
                    ConfidenceToMedian = prediction.ConfidenceToMedian(),
                    PredictedProbability = prediction.Score[i],
                    MaxProbabilityIndex = prediction.Score.Max(),
                    MinProbabilityIndex = prediction.Score.Min(),
                    TheirCarrierAddress = item.TheirCarrierAddress1,
                    TheirCarrierId = item.TheirCarrierId,
                    TheirCarrierName = item.TheirCarrierName,
                    TheirCarrierZip = item.TheirCarrierZip,
                    ClientID = item.ClientID,
                    TheirCarrierString = item.TheirCarrierString,
                    CompressedPolicyNumber = item.CompressedPolicyNumber
                };
                predictedValues.Add(predictedValue);
                var matched = predictedValues.Count(p => p.Answer == p.PredictedValue);
                if(counter % 500 == 0)
                    Console.WriteLine($@"Processed {counter} of {total} : matched => {matched}");

                counter++;
            };
            return predictedValues;
        }



        private static List<CarrierInput> GetTestData(string connection, string sql )
        {
            var testingData = new List<CarrierInput>();
            using (var db = new SqlConnection(connection))
            {
                var newTestingData = db.Query<CarrierInput>(sql, commandTimeout: 360).ToList();
                testingData.AddRange(newTestingData);
            }
            return testingData;
        }


        private static void SaveResultsToCsv(List<CarrierAIInputExcel> predictedValues, string fileprefix)
        {
            using (var writer = new StreamWriter(fileprefix + "_results.csv"))
            using (var csv = new CsvHelper.CsvWriter(writer))
            {
                csv.WriteRecords(predictedValues);
            }
        }

        private static string GetModelType(string dataset)
        {
            return $"CarrierxRef_{dataset}";
        }

    }
}
