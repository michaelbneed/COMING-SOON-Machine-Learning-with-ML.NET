﻿namespace CarrierFindOMatic
{
    public class CarrierAIInputExcel
    {
        public string ClientID { get; set; }
        public string TheirCarrierId { get; set; }
        public string TheirCarrierName { get; set; }
        public string TheirCarrierAddress { get; set; }
        public string TheirCarrierZip { get; set; } 
       public string CompressedPolicyNumber { get; set; }
        public string TheirCarrierString { get; set; }

        //only used for training
 
        public string Answer { get; set; }
        public string PredictedValue { get; set; }
        public bool IsMatched
        {
            get => Answer == PredictedValue;
        }

        public bool IsMatchedWithConfidence
        {
            get => IsMatched && Confidence >= 0.65 && ConfidenceToMedian >= 0.65;
        }
        public double Confidence { get; set; }
        public double ConfidenceToMedian { get; set; }
        public float PredictedProbability { get; set; }
        public float MaxProbabilityIndex { get; set; }
        public float MinProbabilityIndex { get; set; }
        public float NormalizedProbability
        {
            get
            {
                return (PredictedProbability - MinProbabilityIndex) / (MaxProbabilityIndex - MinProbabilityIndex);

            }
        }


    }
}