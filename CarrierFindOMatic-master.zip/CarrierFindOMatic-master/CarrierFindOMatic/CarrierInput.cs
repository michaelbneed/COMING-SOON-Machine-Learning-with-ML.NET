﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.ML.Runtime.Api;
using Newtonsoft.Json;

namespace CarrierFindOMatic
{
    public class CarrierInput
    {

        public string ClientID;


    public string TheirCarrierId
    {
        get => Features[0];
        set => Features[0] = value;
    }

        public string TheirCarrierName
        {
            get => Features[1];
            set => Features[1] = value;
        }

    public string TheirCarrierAddress1
        {
            get => Features[2];
            set => Features[2] = value;
        }

        public string TheirCarrierZip
        {
            get => Features[3];
            set => Features[3] = value;
        }

        public string CompressedPolicyNumber;

        [Column("4")]
        [ColumnName("Label")]
        public string CarrierID;


        public string CarrierIDFinal;

        public string CarrierName;
        public bool IsFriendlyCarrier;
        public bool IsMedicarePartB;
        public bool IsTraditionalBCBS;
        public string TheirCarrierString;




        [Column("0-3")]
        [VectorType(4)] public string[] Features = new string[4];

        public string PredictedValue;


    }
}

