﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarrierFindOMatic
{
    public static class SQLLogic
    {
        public static string carrierTrainingSql(string currentClient)
        {
            return $@"
 SELECT DISTINCT DataSourceID
	,ClientID
	,TheirCarrierID
	,TheirCarrierName
	,TheirCarrierAddress1
	,TheirCarrierZip
	,CompressedPolicyNumber
	,CarrierID
	,CarrierIDFinal
	,CarrierNameFinal
	,CarrierName
	,IsFriendlyCarrier
	,IsMedicarePartB
	,IsTraditionalBCBS
	,TheirCarrierString
FROM [dbo].[vExtract_{currentClient}ALL]
";
        }
        public static string carrierTestingSql(string currentClient)
        {
            return $@"
 SELECT DataSourceID
	,ClientID
	,TheirCarrierID
	,TheirCarrierName
	,TheirCarrierAddress1
	,TheirCarrierZip
	,CompressedPolicyNumber
	,CarrierID
	,CarrierIDFinal
	,CarrierNameFinal
	,CarrierName
	,IsFriendlyCarrier
	,IsMedicarePartB
	,IsTraditionalBCBS
	,TheirCarrierString
FROM [dbo].[vExtract_{currentClient}ALL]
";
        }
    }
}
