﻿using System;

namespace Zotec.ML.Extensions
{
    public class PredictionModelInformation
    {
        public DateTime CreationDate { get; set; }
        public int ID { get; set; }
    }
}