﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using Dapper;
using Microsoft.ML;

namespace Zotec.ML.Extensions
{
    public static class ModelManagement<TInput, TOutput>
        where TInput : class
        where TOutput : class, new()
    {

        public static void SaveModelToDb(PredictionModel<TInput, TOutput> modelToSave, string modelType, string connectionString)
        {
            var sql = @"
 INSERT INTO MachineLearningModels(ModelType,Model)
VALUES(@ModelType, @Model);
";
            MemoryStream modelStream = new MemoryStream();
            modelToSave.WriteAsync(modelStream);
            byte[] model = modelStream.ToArray();
            using (var db = new SqlConnection(connectionString))
            {
                DynamicParameters parameter = new DynamicParameters();

                parameter.Add("@ModelType", modelType, DbType.String, ParameterDirection.Input);
                parameter.Add("@Model", model, DbType.Binary, ParameterDirection.Input);

                var result = db.Execute(sql, commandTimeout: 360, param: parameter);

            }

        }


        public static PredictionModelInformation GetPredictionModelInformation(string connectionString, string modelType)
        {
            var sql = @"
SELECT Top 1 ID,CreationDate FROM  MachineLearningModels 
WHERE ModelType = @ModelType
ORDER BY ID DESC;
";
            var info = new PredictionModelInformation();

            using (var db = new SqlConnection(connectionString))
            {
                DynamicParameters parameter = new DynamicParameters();

                parameter.Add("@ModelType", modelType, DbType.String, ParameterDirection.Input);

                info = (db.Query<PredictionModelInformation>(sql, commandTimeout: 360, param: parameter))
                    .FirstOrDefault();

            }

            return info;

        }




        public static PredictionModel<TInput, TOutput> LoadModelFromDBAsync(string connectionString, string modelType)
        {
            var sql = @"
SELECT Top 1 Model FROM  MachineLearningModels 
WHERE ModelType = @ModelType
ORDER BY ID DESC;
";
            var memoryStream = new MemoryStream();
            using (var db = new SqlConnection(connectionString))
            {
                DynamicParameters parameter = new DynamicParameters();

                parameter.Add("@ModelType", modelType, DbType.String, ParameterDirection.Input);


                var modelBytes = db.Query<Byte[]>(sql, commandTimeout: 360, param: parameter).First();

                memoryStream.Write(modelBytes, 0, modelBytes.Count());

            }

            return (PredictionModel.ReadAsync<TInput, TOutput>(memoryStream)).Result;
  
        }
    }
}
