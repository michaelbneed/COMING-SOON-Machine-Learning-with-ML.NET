﻿using Microsoft.ML;
using Microsoft.ML.Data;
using Microsoft.ML.Models;
using Microsoft.ML.Transforms;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using Dapper;
using Microsoft.ML.Runtime;
using Microsoft.ML.Runtime.EntryPoints;
using Microsoft.ML.Runtime.FastTree.Internal;
using Microsoft.ML.Trainers;


namespace Zotec.ML.Extensions
{
    public partial class ModelBuilder<TInput, TOutput>
       where TInput : class
       where TOutput : class, new()
    {
        private readonly ILearningPipelineItem _algorithm;
        private readonly string _features;
        private LearningPipeline _pipeline;
        public PredictionModel<TInput, TOutput> Model { get; set; }

        public ModelBuilder(ILearningPipelineItem algorithm, string features, string modelType)
        {

            _algorithm = algorithm;
            _features = features;
            Model = null;
           
        }


        public void BuildPipeline(ILearningPipelineLoader trainingData, bool vectorizeFeatures)
        {
            _pipeline = new LearningPipeline();
            _pipeline.Append(trainingData)
                .Append(new Dictionarizer("Label"));

            if (vectorizeFeatures)
            {
                _pipeline.Add(new TextFeaturizer("Features", _features) 
                           {
                                 KeepDiacritics = false, 
                                  KeepPunctuations = false, 
                                  TextCase = TextNormalizerTransformCaseNormalizationMode.Lower, 
                                  OutputTokens = true, 
                                  StopWordsRemover = new PredefinedStopWordsRemover(), 
                                  VectorNormalizer = TextTransformTextNormKind.L2, 
                                  CharFeatureExtractor = new NGramNgramExtractor() { NgramLength = 3, AllLengths = false }, 
                                  WordFeatureExtractor = new NGramNgramExtractor() { NgramLength = 3, AllLengths = true }
                                });

               //   _pipeline.Append(new CategoricalHashOneHotVectorizer(_features));
            }

          //  _pipeline.Append(new ColumnConcatenator("Features", _features))
              _pipeline
                .Append(_algorithm)
                .Append(new PredictedLabelColumnOriginalValueConverter() { PredictedLabelColumn = "PredictedLabel" });
        }


   
        public void BuildAndTrain(ILearningPipelineLoader trainingData, bool vectorizeFeatures )
        {
            BuildPipeline(trainingData, vectorizeFeatures);
          
            Model = _pipeline.Train<TInput, TOutput>();
        }

        

        public CrossValidationOutput<TInput, TOutput> Evaluate(MacroUtilsTrainerKinds kindofTrainer, int numberoffolds)
        {
            
            var cv = new CrossValidator() { Kind = kindofTrainer, NumFolds = numberoffolds }.CrossValidate<TInput, TOutput>(_pipeline);
            return cv;
        }


        public ClassificationMetrics Evaluate(ILearningPipelineLoader testData)
        {
            var metrics = new ClassificationEvaluator().Evaluate(Model, testData);
            return metrics;
        }

        public ClusterMetrics EvaluateCluster(ILearningPipelineLoader testData)
        {
            var metrics = new ClusterEvaluator().Evaluate(Model, testData);
            return metrics;
        }






    }
}
