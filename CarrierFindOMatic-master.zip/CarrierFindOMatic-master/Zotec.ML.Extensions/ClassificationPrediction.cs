﻿using Microsoft.ML.Runtime.Api;
using System;
using System.Linq;
using Microsoft.ML.Runtime;


namespace Zotec.ML.Extensions
{
    public class ClassificationPrediction
    {
        [ColumnName("PredictedLabel")]
        public string PredictedLabel;

        [ColumnName("Score")]
        public float[] Score;

        public double ConfidenceToMedian()
        {
            int numberCount = Score.Count();
            int halfIndex = Score.Count() / 2;
            var sortedNumbers = Score.OrderByDescending(n => n);
            double median;
            if ((numberCount % 2) == 0)
            {
                median = ((sortedNumbers.ElementAt(halfIndex) + sortedNumbers.ElementAt((halfIndex -1))) / 2);
            }
            else
            {
                median = sortedNumbers.ElementAt(halfIndex);
            }
            return sortedNumbers.First() * (1.00 / (sortedNumbers.First() +  median));
        }

        public double ConfidenceToNext()
        {
            int numberCount = Score.Count();
            int halfIndex = Score.Count() / 2;
            var sortedNumbers = Score.OrderByDescending(n => n).ToArray();
           
            return sortedNumbers[0] * (1.00 / (sortedNumbers[0] + sortedNumbers[1]));
        }

        


    }




}
