﻿using Microsoft.ML.Runtime.Api;

namespace Zotec.ML.Extensions
{

        public class ClusterPrediction
        {
            [ColumnName("PredictedLabel")]
            public uint PredictedClusterId;

            [ColumnName("Score")]
            public float[] Distances;
        }

}
